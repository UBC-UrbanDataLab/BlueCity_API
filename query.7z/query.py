"""
BlueCity Sensor Aggregate Data Query Tutorial,
By Mohammad Pourmeydani Last Updated: Feb 12, 2021
This notebook will include the BlueCity Sensor API features and how to query data from their API using Python. 
1. Request a token from BlueCity to use API access. This token will allow you to view the sensor data of the sensors installed at University Blvd and Westbrook Mall Ave at UBC Vancouver. 
2. Check the README file to learn what to enter for UDID, fromDate, toDate, fields and aggregation. 
"""

##Aggregated HTTP API
import requests


if __name__ == "__main__":

    url = "https://api.bluecitytechnology.com/s/ad"
    UDID = "UDID"
    fromDate = "fromDate"
    toDate = "toDate"
    fields = "fields"
    aggregation = "aggregation"
    token = "token"
    headers = {'content-type': 'application/json', 'Authorization': token}

    resp = requests.get(url="{}?UDID={}&fdate={}&tdate={}&f={}&a={}".format(url, UDID, fromDate, toDate, fields, aggregation), headers=headers)
    print(resp.status_code)
    if resp.status_code == 200 or resp.status_code == 201:
        print(resp.content)
